/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author BARBARA
 */
public class Servicio {
    private int id_servicio;
    private int id_cliente;
    private int id_trasnporte;
    private int estado;
    private String fecha_servicio;
    private String hora_servicio;
    private int tipo_servicio;
    private String descripcion_servicio;
    
    
}
