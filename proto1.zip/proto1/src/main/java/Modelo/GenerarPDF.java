/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.FlowLayout;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author Yeisson
 */
public class GenerarPDF extends JFrame{
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    // Agrega aquí los demás JTextField necesarios

    public GenerarPDF() {
        setTitle("Generador de PDF");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        textField1 = new JTextField(19);
        textField2 = new JTextField(20);
        textField3 = new JTextField(21);
        textField4 = new JTextField(22);
        textField5 = new JTextField(2);
        // Agrega aquí los demás JTextField necesarios

        JButton generarButton = new JButton("Generar PDF");
        generarButton.addActionListener(e -> generarPDF());

        add(new JLabel("Empresa : "));
        add(textField1);
        add(new JLabel("RUC : "));
        add(textField2);
        add(new JLabel("Cantidad de Servicios : "));
        add(textField3);
        add(new JLabel("Precio por Servicio : "));
        add(textField4);
        add(new JLabel("Total S/.: "));
        add(textField5);
        // Agrega aquí los demás JTextField necesarios
        add(generarButton);

        setVisible(true);
    }

    public void generarPDF() {
        String rutaArchivo = "Factura.pdf"; // Cambia aquí el nombre y la ruta del archivo PDF

        try {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(rutaArchivo));
            document.open();

            // Obtener los datos de los JTextField
            String dato1 = textField1.getText();
            String dato2 = textField2.getText();
            String dato3 = textField3.getText();
            String dato4 = textField4.getText();
            String dato5 = textField5.getText();
            // Agrega aquí los demás datos de los JTextField necesarios

            // Agregar los datos al documento PDF
            document.add(new Paragraph("Empresa : " + dato1));
            document.add(new Paragraph("RUC : " + dato2));
            document.add(new Paragraph("Cantidad de Servicios : " + dato3));
            document.add(new Paragraph("Precio por Servicio : " + dato4));
            document.add(new Paragraph("Total S/.: " + dato5));
            // Agrega aquí los demás datos de los JTextField necesarios

            document.close();

            JOptionPane.showMessageDialog(this, "PDF generado correctamente.");
        } catch (DocumentException | FileNotFoundException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al generar el PDF.");
        }
    }

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GenerarPDF());
    }

    
}
