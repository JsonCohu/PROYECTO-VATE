package com.mycompany.proto1;

public class JavaMail {

    public static void main(String[] args) {
        LogIn log = new LogIn();
        log.setVisible(true);

    }

}
